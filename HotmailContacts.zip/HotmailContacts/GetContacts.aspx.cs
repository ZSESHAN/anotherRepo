﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HotmailContacts
{
    public partial class GetContacts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            GetMsnContacts("M5c01dd34-306f-e969-6a1f-5429045d43a8");
            if (Request.QueryString["code"] != null)
            {
                GetMsnContacts(Request.QueryString["code"].ToString());
            }

            //You Can Call This Method In Method In Your .aspx Page

        }
        private void GetMsnContacts(string code)
        {
            MsnImport msnImport = new MsnImport(0);
            List<string> emaillist = new List<string>();
            emaillist = msnImport.GetMsnContacts(code);
            ddlContacts.DataSource = emaillist;
            ddlContacts.DataBind();
            lblCount.Text = emaillist.Count().ToString();
        }

    }
}
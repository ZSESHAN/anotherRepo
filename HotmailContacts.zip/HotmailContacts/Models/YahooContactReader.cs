﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HotmailContacts.Models
{
    /// <summary>
    /// Summary description for YahooContactReader
    /// </summary>
    public class YahooContactReader
    {
        public YahooContactReader()
        {
            //
            // TODO: Add constructor logic here
            //
        }
    }
    public class YahooContactsData
    {
        public YContacts contacts;
    }
    public class YContacts
    {
        public List<YContact> contact { get; set; }
    }
    public class YContact
    {
        public List<YFields> fields { get; set; }
    }
    public class YFields
    {
        public int id { get; set; }
        public string type { get; set; }
        public object value { get; set; }
    }
}
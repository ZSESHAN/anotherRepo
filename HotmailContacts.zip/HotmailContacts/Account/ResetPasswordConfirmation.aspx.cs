﻿using System.Web.UI;

namespace HotmailContacts.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}
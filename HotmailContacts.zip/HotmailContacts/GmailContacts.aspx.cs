﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Google.GData.Client;

using Google.GData.Extensions;
using Google.GData.Apps;

namespace HotmailContacts
{
    public partial class GmailContacts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string clientId = "790083407679-k8cenpcvqaer82g58i3pfg851334n2uh.apps.googleusercontent.com";
                string clientSecrete = "fsMg-RPrHqIG_GWULrfTfVuh";
                //string redirect_uri = "http://pm.somee.com/GmailContacts";
                string redirect_uri = "http://localhost:5548/GmailContacts.aspx";
                string url = "https://accounts.google.com/o/oauth2/auth?approval_prompt=force&scope=https://www.google.com/m8/feeds/&response_type=code&state=/profile&redirect_uri=" + redirect_uri + "&client_id=" + clientId + "&hl=en-GB&from_login=1&as=-3bdef63ed40098e9";
                hypAllowAccess.NavigateUrl = url;
                if (!string.IsNullOrEmpty(Request.QueryString["code"]))
                {
                    string code = Request.QueryString["code"];
                    //string redPath = "http://pm.somee.com/GmailContacts";
                    string redPath = "http://localhost:5548/GmailContacts.aspx";
                    byte[] buffer = Encoding.ASCII.GetBytes("code=" + code + "&client_id=" + clientId + "&client_secret=" + clientSecrete + "&redirect_uri=" + redPath + "&grant_type=authorization_code");
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create("https://accounts.google.com/o/oauth2/token");
                    req.Method = "POST";
                    req.ContentType = "application/x-www-form-urlencoded";
                    req.ContentLength = buffer.Length;

                    Stream strm = req.GetRequestStream();
                    strm.Write(buffer, 0, buffer.Length);
                    strm.Close();

                    HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
                    //Response.Write(((HttpWebResponse)resp).StatusDescription);
                    string detail = "";//((HttpWebResponse)resp).StatusDescription;
                                       // lblTest.Text = ((HttpWebResponse)resp).StatusDescription;
                    using (var sr = new StreamReader(resp.GetResponseStream()))
                    {
                        detail = sr.ReadToEnd();
                    }
                    var objJson = JObject.Parse(detail);
                    //lblTest.Text += (string)objJson["access_token"];
                    OAuth2Parameters parameters = new OAuth2Parameters();
                    parameters.AccessToken = (string)objJson["access_token"];
                    //parameters.RefreshToken = credential.Token.RefreshToken;
                    string lstEmail = RunContactsSample(parameters);
                    litEmail.Text += lstEmail;
                }
            }
        }
        private static String RunContactsSample(OAuth2Parameters parameters)
        {
            try
            {
                RequestSettings settings = new RequestSettings("My Test App", parameters);
                Google.Contacts.ContactsRequest cr = new Google.Contacts.ContactsRequest(settings);
                Google.GData.Client.Feed<Google.Contacts.Contact> f = cr.GetContacts();
                string lstEmail = string.Empty;
                foreach (Google.Contacts.Contact c in f.Entries)
                {
                    //lstEmail += string.Concat(lstEmail,":Name",c.Name.FullName,"Email:", c.Emails.FirstOrDefault());
                    Int32 count = 1;
                    foreach (EMail email in c.Emails)
                    {
                        lstEmail += String.Concat("<br />Email For Friend  ", count, " <b>", email.Address, "<b>");
                        count++;
                    }
                    //Console.WriteLine(c.Name.FullName);
                }
                return lstEmail;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HotmailContacts.Models;

namespace HotmailContacts
{
    public partial class yahoo_contact_reader : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["code"] != null)
                GetAccessToken();
        }
        protected void yahooButton_Click(object sender, EventArgs e)
        {
            string consumerKey = "dj0yJmk9UVliV1EzUFBHbnJkJmQ9WVdrOVdtbHBjMmgyTnpRbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1hYg--";
            string returnUrl = "http://pm.somee.com/yahoo-contact-reader.aspx";
            //String returnUrl = "http://localhost:6851/yahoo-contact-reader.aspx";
            /*Space in returnUrl will give error*/

            /*Sending User To Authorize Access Page*/
            string url = "https://api.login.yahoo.com/oauth2/request_auth?client_id=" + consumerKey + "&redirect_uri=" + returnUrl + "&response_type=code&language=en-us";
            // String url = "https://api.login.yahoo.com/oauth2/request_auth?client_id=dj0yJmk9ak5IZ2x5WmNsaHp6JmQ9WVdrOVNqQkJUMnRYTjJrbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1hYQ--&redirect_uri=oob&response_type=code&language=en-us";
            Response.Redirect(url);
            /*End*/
        }
        public void GetAccessToken()
        {
            string consumerKey = "dj0yJmk9UVliV1EzUFBHbnJkJmQ9WVdrOVdtbHBjMmgyTnpRbWNHbzlNQS0tJnM9Y29uc3VtZXJzZWNyZXQmeD1hYg--";
            string consumerSecret = "d9ad8bfc15b29f37dce9458d58f54b2d18facd43";
            string returnUrl = "http://pm.somee.com/yahoo-contact-reader.aspx";
            //string returnUrl = "http://localhost:6851/yahoo-contact-reader.aspx";

            /*Exchange authorization code for Access Token by sending Post Request*/
            Uri address = new Uri("https://api.login.yahoo.com/oauth2/get_token");

            // Create the web request  
            HttpWebRequest request = WebRequest.Create(address) as HttpWebRequest;

            // Set type to POST  
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            byte[] headerByte = System.Text.Encoding.UTF8.GetBytes(consumerKey + ":" + consumerSecret);
            string headerString = System.Convert.ToBase64String(headerByte);
            request.Headers["Authorization"] = "Basic " + headerString;

            // Create the data we want to send  
            StringBuilder data = new StringBuilder();
            data.Append("client_id=" + consumerKey);
            data.Append("&client_secret=" + consumerSecret);
            data.Append("&redirect_uri=" + returnUrl);
            data.Append("&code=" + Request.QueryString["code"]);
            data.Append("&grant_type=authorization_code");

            // Create a byte array of the data we want to send  
            byte[] byteData = UTF8Encoding.UTF8.GetBytes(data.ToString());

            // Set the content length in the request headers  
            request.ContentLength = byteData.Length;

            // Write data  
            using (Stream postStream = request.GetRequestStream())
            {
                postStream.Write(byteData, 0, byteData.Length);
            }

            // Get response  
            string responseFromServer = "";
            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    // Get the response stream  
                    StreamReader reader = new StreamReader(response.GetResponseStream());
                    responseFromServer = reader.ReadToEnd();

                    GetContact(responseFromServer);
                }
            }
            catch (Exception ex)
            {
            }
        }
        private void GetContact(string responseFromServer)
        {
            /*Yahoo OAuth 2.0 important Url
              https://developer.yahoo.com/oauth2/guide/
              https://developer.yahoo.com/dotnet/howto-rest_cs.html
              https://developer.yahoo.com/oauth/guide/oauth-make-request.html
              http://json2csharp.com/
              https://www.jsoneditoronline.org/ 
            */

            responseFromServer = responseFromServer.Substring(1, responseFromServer.Length - 2);
            string accessToken = "", xoauthYahooGuid = "", refreshToken = "";
            string[] splitByComma = responseFromServer.Split(',');
            foreach (string value in splitByComma)
            {
                if (value.Contains("access_token"))
                {
                    string[] accessTokenSplitByColon = value.Split(':');
                    accessToken = accessTokenSplitByColon[1].Replace('"'.ToString(), "");
                }
                else if (value.Contains("xoauth_yahoo_guid"))
                {
                    string[] xoauthYahooGuidSplitByColon = value.Split(':');
                    xoauthYahooGuid = xoauthYahooGuidSplitByColon[1].Replace('"'.ToString(), "");
                }
                else if (value.Contains("refresh_token"))
                {
                    string[] refreshTokenSplitByColon = value.Split(':');
                    refreshToken = refreshTokenSplitByColon[1].Replace('"'.ToString(), "");
                }
            }

            try
            {
                /*Yahoo Api Request*/
                HttpWebRequest request = WebRequest.Create("https://social.yahooapis.com/v1/user/" + xoauthYahooGuid + "/contacts?format=json") as HttpWebRequest;
                request.Headers["Authorization"] = "Bearer " + accessToken;

                string contactResponse = "";
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    StreamReader reader = new StreamReader(response.GetResponseStream());
                    contactResponse = reader.ReadToEnd();
                }
                /*End*/
                //dataDiv.InnerHtml = contactResponse;
                /*JSON Seriazlization*/
                StringBuilder yahooContactStringBuilder = new StringBuilder();
                YahooContactsData yahooContactsData = new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<YahooContactsData>(contactResponse);
                int i = 1;
                foreach (YContact yContact in yahooContactsData.contacts.contact)
                {
                    List<YFields> fields = yContact.fields;
                    foreach (YFields data in fields)
                    {
                        if (data.value.ToString().Contains("@"))
                        {
                            yahooContactStringBuilder.Append(i + "&nbsp;").Append(data.value.ToString()).Append("<br/>");
                            i++;
                        }
                    }
                }
                /*End*/
                dataDiv.InnerHtml = yahooContactStringBuilder.ToString();

            }
            catch (WebException ex)
            {
                Response.Write(ex.Message);
            }
        }
    }
}